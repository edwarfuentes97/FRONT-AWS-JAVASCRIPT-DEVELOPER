
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'edwarfuentes97',
  applicationName: 'shop-angular-cloudfront-app',
  appUid: 'GSfYhyksm2cBw8BWDl',
  orgUid: '8d9a9955-9ef7-47bc-9b15-d2d2b884d224',
  deploymentUid: '9d6fdd93-4603-4e70-82b4-b9f2f866b750',
  serviceName: 'js-cc-shop-angular-cloudfront',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'js-cc-shop-angular-cloudfront-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}