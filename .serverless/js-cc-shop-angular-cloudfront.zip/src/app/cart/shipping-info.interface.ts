export interface ShippingInfo {
  comment?: string;
  address: string;
  firstName: string;
  lastName: string;
}
